import boto3
import json
import datetime
import logging
import os

log = logging.getLogger()
log.setLevel(logging.INFO)

IPSET_ID = os.environ['IPSET_CLOUD_SNIPER_AUTOMATIC_BLOCK_THIS_IPS']
DYNAMO_TABLE = os.environ['DYNAMO_TABLE_CLOUD_SNIPER']
s = boto3.session.Session(region_name=os.environ['AWS_REGION'])

json_a = []
json_b = []

message = []

sqs = s.client('sqs')
queue_url = 'https://sqs.us-east-1.amazonaws.com/155165559527/sqs_queue_cloud_sniper'								 
waf = s.client('waf-regional')
ec2 = s.client('ec2')
dynamodb = s.resource('dynamodb')
r_ec2 = s.resource('ec2')


networkConnectionAction = [
"UnauthorizedAccess:EC2/SSHBruteForce",
"Recon:EC2/Portscan",
]

portProbeAction = [
"Recon:EC2/PortProbeUnprotectedPort",
]

awsApiCallAction = [
"UnauthorizedAccess:IAMUser/ConsoleLogin",
"UnauthorizedAccess:IAMUser/ConsoleLoginSuccess.B",
"UnauthorizedAccess:IAMUser/InstanceCredentialExfiltration",
"UnauthorizedAccess:IAMUser/MaliciousIPCaller.Custom",
"UnauthorizedAccess:IAMUser/MaliciousIPCaller",
"UnauthorizedAccess:IAMUser/TorIPCaller",
"Stealth:IAMUser/CloudTrailLoggingDisabled",
"Stealth:IAMUser/LoggingConfigurationModified",
"Stealth:IAMUser/PasswordPolicyChange",
"ResourceConsumption:IAMUser/ComputeResources",
"Recon:IAMUser/MaliciousIPCaller.Custom",
"Recon:IAMUser/MaliciousIPCaller",
"Recon:IAMUser/NetworkPermissions",
"Recon:IAMUser/ResourcePermissions",
"Recon:IAMUser/TorIPCaller",
"Recon:IAMUser/UserPermissions",
"Persistence:IAMUser/NetworkPermissions",
"Persistence:IAMUser/ResourcePermissions",
"Persistence:IAMUser/UserPermissions",
"PenTest:IAMUser/KaliLinux",
"PenTest:IAMUser/PentooLinux",
"PenTest:IAMUser/ParrotLinux",
"Policy:IAMUser/RootCredentialUsage",

]

instanceDetails = [
"Trojan:EC2/BlackholeTraffic!DNS",
"Trojan:EC2/DGADomainRequest.B",
"Trojan:EC2/DGADomainRequest.C!DNS",
"Trojan:EC2/DNSDataExfiltration",
"Trojan:EC2/DriveBySourceTraffic!DNS",
"Trojan:EC2/DropPoint!DNS",
"Trojan:EC2/PhishingDomainRequest!DNS",
"Trojan:EC2/BlackholeTraffic",
"Trojan:EC2/DropPoint",
"CryptoCurrency:EC2/BitcoinTool.B!DNS",
"CryptoCurrency:EC2/BitcoinTool.B",
"Backdoor:EC2/C&CActivity.B!DNS",
"Backdoor:EC2/Spambot",
"Backdoor:EC2/XORDDOS",
"UnauthorizedAccess:EC2/MaliciousIPCaller.Custom",
"UnauthorizedAccess:EC2/RDPBruteForce",      
"UnauthorizedAccess:EC2/TorClient", 
"UnauthorizedAccess:EC2/TorIPCaller",
"UnauthorizedAccess:EC2/TorRelay",
"Behavior:EC2/NetworkPortUnusual",
"Behavior:EC2/TrafficVolumeUnusual",
]


def read_sqs():

	response = sqs.receive_message(
		QueueUrl=queue_url,
		MaxNumberOfMessages=10,
		MessageAttributeNames=[
			'All'
		],		
	)

	if 'Messages' in response:
		return response['Messages']
	else:
		return


def search_ioc():	
	
	log.info("searching for IOC ...")

	global json_a
	global json_b
	global message

	for b in message:		
		body = b['Body']
		
		data = json.loads(body)

		try:	
			flag = 0
			for e in networkConnectionAction:
				if data["detail"]["type"] == e:
					flag = 1
					break

			for e in portProbeAction:
					if data["detail"]["type"] == e:
						flag = 2
						break

			for e in awsApiCallAction:
				if data["detail"]["type"] == e:
					flag = 3
					break

			for e in instanceDetails:
				if data["detail"]["type"] == e:
					flag = 4
					break
			
			if flag == 1:
				ioc = []
				
				account_id = data["detail"]["accountId"]				
				region = data["region"]
				subnet_id = data["detail"]["resource"]["instanceDetails"]["networkInterfaces"][0]["subnetId"]
				nacl_id = get_netacl_id(subnet_id)
				src_ip = json.dumps(data["detail"]["service"]["action"]["networkConnectionAction"]["remoteIpDetails"]["ipAddressV4"])		
				instance_id = data["detail"]["resource"]["instanceDetails"]["instanceId"]
				ttp = data["detail"]["type"]
							
				if nacl_id != '':									
					ioc = ttp +","+account_id+","+region +","+subnet_id+","+src_ip+","+instance_id+","+nacl_id
				else:
					ioc = ttp +","+account_id+","+region +","+subnet_id+","+src_ip+","+instance_id+","+"external_nacl"

				if len(json_a) == 0:
					json_a.append(ioc)					
				else:
					for e in json_a:
						if e != ioc:											
							json_a.append(ioc)				
				
			elif flag == 2:
				ioc = []				
				
				account_id = data["detail"]["accountId"]				
				region = data["region"]
				subnet_id = data["detail"]["resource"]["instanceDetails"]["networkInterfaces"][0]["subnetId"]				
				nacl_id = get_netacl_id(subnet_id)
				src_ip = (json.dumps(data["detail"]["service"]["action"]["portProbeAction"]["portProbeDetails"][0]["remoteIpDetails"]["ipAddressV4"])).strip('"')				
				instance_id = data["detail"]["resource"]["instanceDetails"]["instanceId"]
				ttp = data["detail"]["type"]
				
				if nacl_id != '':									
					ioc = ttp +","+account_id+","+region +","+subnet_id+","+src_ip+","+instance_id+","+nacl_id
				else:
					ioc = ttp +","+account_id+","+region +","+subnet_id+","+src_ip+","+instance_id+","+"external_nacl"

				if len(json_a) == 0:
					json_a.append(ioc)					
				else:
					for e in json_a:
						if e != ioc:											
							json_a.append(ioc)				
				
			elif flag == 3:
				ioc = []				
				
				account_id = data["detail"]["accountId"]			
				region = data["region"]				
				src_ip = json.dumps(data["detail"]["service"]["action"]["awsApiCallAction"]["remoteIpDetails"]["ipAddressV4"])
				ttp = data["detail"]["type"]
												
				ioc = ttp +","+account_id+","+region +","+src_ip

				if len(json_b) == 0:
					json_b.append(ioc)					
				else:
					for e in json_b:
						if e != ioc:											
							json_b.append(ioc)	
							
			else:				
				account_id = data["detail"]["accountId"]				
				region = data["region"]		
				subnet_id = data["detail"]["resource"]["instanceDetails"]["networkInterfaces"][0]["subnetId"]
				nacl_id = get_netacl_id(subnet_id)
				src_ip = json.dumps(data["detail"]["resource"]["instanceDetails"]["networkInterfaces"][0]["publicIp"])		
				instance_id = data["detail"]["resource"]["instanceDetails"]["instanceId"]
				ttp = data["detail"]["type"]
											
				if nacl_id != '':									
					ioc = ttp +","+account_id+","+region +","+subnet_id+","+src_ip+","+instance_id+","+nacl_id
				else:
					ioc = ttp +","+account_id+","+region +","+subnet_id+","+src_ip+","+instance_id+","+"external_nacl"

				if len(json_a) == 0:
					json_a.append(ioc)					
				else:
					for e in json_a:
						if e != ioc:											
							json_a.append(ioc)				

		except Exception as e:
				print ("json could not be parsed:",e)

	
	   
def get_netacl_id(subnet_id):
	log.info("getting nacl id ...")

	try:        
		response = ec2.describe_network_acls(
			Filters=[
				{
					'Name': 'association.subnet-id',
					'Values': [
						subnet_id,
					]
				}
			]
		)
		
		nacls = response['NetworkAcls'][0]['Associations']
		
		for n in nacls:            
			if n['SubnetId'] == subnet_id:
				nacl_id = n['NetworkAclId']
				#print (nacl_id)
		
		return nacl_id

	except:
		return ''


def incident_and_response():

	log.info("incident and response ...")

	ts =  str(datetime.datetime.now())

	ujsa = set(json_a)
	ujsb = set(json_b)

	for jsa in ujsa:
		ttp,account_id,region,subnet_id,src_ip,instance_id,nacl_id = jsa.split(",")

		update_ip_set(src_ip)
		update_table_attackers(src_ip,ts,subnet_id,region,account_id,instance_id,nacl_id,ttp)			
		if nacl_id != "external_nacl":
			create_nacl_rule(nacl_id,src_ip)

	for jsb in ujsb:
		ttp,account_id,region,src_ip = jsb.split(",")

		update_ip_set(src_ip)
		update_table_attackers(src_ip,ts,subnet_id,region,account_id,instance_id,nacl_id,ttp)		
		if nacl_id != "external_nacl":
			create_nacl_rule(nacl_id,src_ip)	

def update_ip_set(src_ip):

	log.info("updating ip set ...")

	log.info("updating ip set...")
	try:
		response = waf.update_ip_set(
			IPSetId=IPSET_ID,
			ChangeToken=waf.get_change_token()['ChangeToken'],
			Updates=[{
				'Action': 'INSERT',
				'IPSetDescriptor': {
					'Type': 'IPV4',
					'Value': "%s/32"%src_ip
				}
			}]
		)       
	except Exception as e:
		print ("WAF IPSet could not be updated",e)


def update_table_attackers(attacker_ip, timestamp, subnet_id, region, account_id,intance_id,nacl_id,ttp):

	log.info("updating table ...")

	log.info("updating table attackers ...")
	table = dynamodb.Table(DYNAMO_TABLE)

	try:
		response = table.put_item(
			Item={
				'ip_attacker': str(attacker_ip),
				'timestamp': str(timestamp),
				'subnet_id': str(subnet_id),
				'region': str(region),
				'account_id': str(account_id),
				'intance_id': str(intance_id),
				'nacl_id': str(nacl_id),
				'ttp': str(ttp)
				}
			)

	except Exception as e:
		print ("table could not be updated",e)


def create_nacl_rule(nacl_id, attacker_ip):

	log.info("creating nacl rule ...")
	
	rule = get_rules(nacl_id)
	i = min(rule) + 1

	if min(rule) == 100:
		rule_no = 1
	else:
		count = 1
		while count < 98:
			count += 1
			
			if i < 100 and i not in rule:
				rule_no = i
				break
			else:
				i += 1

	nacl = r_ec2.NetworkAcl(nacl_id)

	response = nacl.create_entry(
	CidrBlock = attacker_ip + '/32',
	Egress=False,
	PortRange={
		'From': 0,
		'To': 65535
	},
	Protocol='-1',
	RuleAction='deny',
	RuleNumber= rule_no
	)

	if response['ResponseMetadata']['HTTPStatusCode'] == 200:
		return True
	else:
		return False


def get_rules(nacl_id):
	
	ports = []

	response = ec2.describe_network_acls(
		NetworkAclIds=[ 
			nacl_id,
		],
	)

	data = response['NetworkAcls'][0]['Entries']
	
	for d in data:		
		ports.append(d['RuleNumber'])
	
	return set(ports)
		
def delete_sqs():

	global message
	
	log.info("deleting sqs queue ...")
	try:
		for rh in message:
			receipt_handle= rh['ReceiptHandle']

			sqs.delete_message(
				QueueUrl=queue_url,
				ReceiptHandle=receipt_handle
				)			
	except Exception as e:
				print ("SQS queu could not be deleted",e)



def cloud_sniper (event, context):

	global message

	log.info("GuardDuty findings: %s" % json.dumps(event))

	try:
		message = read_sqs()
		if message:
			search_ioc()
			incident_and_response()	
			delete_sqs()

			log.info("Properly processed findings")
		else:
			print ("There is no new message in the queue")
		
	except Exception as e:
		log.error('Failure to process GD finding.')
		raise